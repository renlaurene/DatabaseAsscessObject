package mmx.Service;

import java.util.List;

import mmx.Domain.Course;
import mmx.Domain.Student;

public interface TuitionCaculateService {
	
	public double computeTutition(Student student, List<Course> courses);
}
