package mmx.Service;

import java.util.List;

import mmx.Domain.Course;
import mmx.Domain.Student;

public interface CheckoutService {
	
	public void checkout(Student student, List<Course> courses, String creditCardNum);
}
