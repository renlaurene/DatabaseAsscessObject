package mmx.Domain;

public class Course {
	private String courseName;
	private String departName;
	private boolean graduate;
	private int numberOfUnits;
	private int stuEnrolled;
	
	
	public Course(String courseName, String departName, boolean graduate, int numberOfUnits, int stuEnrolled) {
		this.courseName = courseName;
		this.departName = departName;
		this.graduate = graduate;
		this.numberOfUnits = numberOfUnits;
		this.stuEnrolled = stuEnrolled;
	}
	
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getDepartName() {
		return departName;
	}
	public void setDepartName(String departName) {
		this.departName = departName;
	}
	public boolean isGraduate() {
		return graduate;
	}
	public void setGraduate(boolean graduate) {
		this.graduate = graduate;
	}
	public int getNumberOfUnits() {
		return numberOfUnits;
	}
	public void setNumberOfUnits(int numberOfUnits) {
		this.numberOfUnits = numberOfUnits;
	}
	public int getStuEnrolled() {
		return stuEnrolled;
	}
	public void setStuEnrolled(int stuEnrolled) {
		this.stuEnrolled = stuEnrolled;
	}
	
	
}
