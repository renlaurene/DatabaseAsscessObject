package mmx.serviceImp;

import java.util.List;

import mmx.Domain.Course;
import mmx.Domain.Student;
import mmx.Service.CheckoutService;
import mmx.Service.PaymentService;
import mmx.Service.TuitionCaculateService;

public class CheckoutPayment implements CheckoutService {
	
	private PaymentService paymentService;
	private TuitionCaculateService tuitionCaculateService;
	
	@Override
	public void checkout(Student student, List<Course> courses, String creditCardNum) {
		
		//Add courses to student and update the enrollment number
		List<Course> studentCourses = student.getCourses();
		for (Course course: courses) {
			studentCourses.add(course);
			course.setStuEnrolled(course.getStuEnrolled()+1);
		}
		
		//Compute the tuition bill
		double amount = tuitionCaculateService.computeTutition(student, courses);
		
		//Process Payment
		paymentService.makePayment(student, amount, creditCardNum);
	}
	
}
