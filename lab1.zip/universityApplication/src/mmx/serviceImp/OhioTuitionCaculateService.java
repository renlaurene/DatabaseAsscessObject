package mmx.serviceImp;

import java.util.List;

import mmx.Domain.Course;
import mmx.Domain.Student;
import mmx.Service.TuitionCaculateService;

public class OhioTuitionCaculateService implements TuitionCaculateService {
	
	@Override
	public double computeTutition(Student student, List<Course> courses) {
		int totalUnits = 0;
		
		List<Course> studentCourses = student.getCourses();
		for (Course course: courses) {
			studentCourses.add(course);
			course.setNumberOfUnits(course.getNumberOfUnits() + totalUnits);
		}
		
	}

}
