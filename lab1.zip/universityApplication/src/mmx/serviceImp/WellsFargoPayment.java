package mmx.serviceImp;

import mmx.Domain.Student;
import mmx.Service.PaymentService;

public class WellsFargoPayment implements PaymentService {

	@Override
	public void makePayment(Student student, double amount, String creditCardNum) {
		System.out.println("Using the Wells Fargo credit card processor to process credit card number" + creditCardNum
				+ "for" + student.getStuName() + "Payment of" + amount);
		
	}
}
