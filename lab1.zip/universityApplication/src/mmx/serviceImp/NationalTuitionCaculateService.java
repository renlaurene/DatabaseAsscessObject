package mmx.serviceImp;

import java.util.List;

import mmx.Domain.Course;
import mmx.Domain.Student;
import mmx.Service.TuitionCaculateService;

public class NationalTuitionCaculateService implements TuitionCaculateService {
	
	@Override
	public double computeTutition(Student student, List<Course> courses) {
		int totalTuition;
		int totalUnits = 0;
		
		List<Course> studentCourses = student.getCourses();
		for (Course course: courses) {
			studentCourses.add(course);
			course.setNumberOfUnits(course.getNumberOfUnits() + totalUnits);
		}
		
		if( student.isIntelStu() ) {
			totalTuition = 500 * totalUnits;
		}else {
			totalTuition = 230 * totalUnits;
		}
		return totalTuition;
	}

}
