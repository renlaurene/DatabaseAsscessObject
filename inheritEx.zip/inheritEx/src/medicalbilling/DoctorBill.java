package medicalbilling;

public class DoctorBill extends MedicalBill {
	
	private String doctorName; 
	private double minutes; 
	
	public DoctorBill(String patientChartNum, String doctorName, double minutes)
			throws IllegalArgumentException{
		super(patientChartNum); // first statement, if no specify then call default
		//super();// default constructor; otherwise compile error 
		this.setBillAmount(0.0); 
	}
	
	public double getMinutes(){
		return minutes; 
	}
	
	public void setMinutes(double minutes){
		this.minutes = minutes; 
	}
	
	public String getDoctorName(){
		return doctorName; 
	}
	
	public void setDoctorName(String doctorName){
		this.doctorName = doctorName; 
	}

}




