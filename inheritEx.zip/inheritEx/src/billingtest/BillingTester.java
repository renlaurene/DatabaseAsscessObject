package billingtest;

import medicalbilling.DoctorBill;
import medicalbilling.LabBill; 
import medicalbilling.MedicalBill;

public class BillingTester{
	
	public static void main(String[] args){
		MedicalBill bill; 
		bill = new MedicalBill("AAA0012");
			
		DoctorBill billDoc; 
		billDoc = new DoctorBill("AAA0012", null, 0);
		
		LabBill billLab;
		billLab = new LabBill("AAA012", null, 0);
		System.out.println(billDoc.getBillAmount());
		System.out.println(billLab.getBillAmount());
	}

}
